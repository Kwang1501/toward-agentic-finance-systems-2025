# FinCoT: Grounding Chain-of-Thought in Expert Financial Reasoning
![img](./images/intro/FinCoT.png)

**Citation**
```bash
@misc{nitarach2025fincotgroundingchainofthoughtexpert,
      title={FinCoT: Grounding Chain-of-Thought in Expert Financial Reasoning}, 
      author={Natapong Nitarach and Warit Sirichotedumrong and Panop Pitchayarthorn and Pittawat Taveekitworachai and Potsawee Manakul and Kunat Pipatanakul},
      year={2025},
      eprint={2506.16123},
      archivePrefix={arXiv},
      primaryClass={cs.CL},
      url={https://arxiv.org/abs/2506.16123}, 
}
```